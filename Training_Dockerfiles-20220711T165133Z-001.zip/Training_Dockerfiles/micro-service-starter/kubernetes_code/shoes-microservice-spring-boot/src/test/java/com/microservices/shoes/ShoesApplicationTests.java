package com.microservices.shoes;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
