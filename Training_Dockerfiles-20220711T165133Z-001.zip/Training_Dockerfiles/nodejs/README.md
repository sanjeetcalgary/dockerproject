Build Image:
docker build . -t <your username>/node-web-app

Run the Image:
docker run -p 8080:8080 -d <your username>/node-web-app
