# Multistage builds for C language
```
https://www.ardanlabs.com/blog/2020/02/docker-images-part1-reducing-image-size.html
```