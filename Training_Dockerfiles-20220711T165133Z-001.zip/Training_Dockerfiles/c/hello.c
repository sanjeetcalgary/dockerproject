/* hello.c */
int main () {
  puts("Hello, world!");
  return 0;
}