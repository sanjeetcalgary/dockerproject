# Hello Whale
This is a demo example

### Build and run
```
docker build -t kunchalavikram/hellowhale:latest .
docker run -d --name demo -p 80:80 kunchalavikram/hellowhale:latest
```
